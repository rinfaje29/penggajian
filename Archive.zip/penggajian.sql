-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 29, 2024 at 02:50 AM
-- Server version: 8.0.30
-- PHP Version: 8.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penggajian`
--

-- --------------------------------------------------------

--
-- Table structure for table `absensi`
--

CREATE TABLE `absensi` (
  `id_absensi` int NOT NULL,
  `nip_pegawai` char(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `kode_jab` char(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `jk_absensi` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `hadir` int NOT NULL,
  `sakit` int NOT NULL,
  `mangkir` int NOT NULL,
  `bulan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `absensi`
--

INSERT INTO `absensi` (`id_absensi`, `nip_pegawai`, `kode_jab`, `jk_absensi`, `hadir`, `sakit`, `mangkir`, `bulan`) VALUES
(1369, '201210012', 'JA14', 'Laki - laki', 1, 0, 29, '112024'),
(1370, '201210014', 'JA14', 'Perempuan', 29, 0, 1, '112024'),
(1371, '201210013', 'JA05', 'Laki - laki', 30, 0, 0, '112024');

-- --------------------------------------------------------

--
-- Table structure for table `divisi`
--

CREATE TABLE `divisi` (
  `id_divisi` int NOT NULL,
  `nama_divisi` varchar(128) NOT NULL,
  `deskripsi` varchar(128) NOT NULL,
  `ketua_divisi` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `divisi`
--

INSERT INTO `divisi` (`id_divisi`, `nama_divisi`, `deskripsi`, `ketua_divisi`) VALUES
(1002, 'Danru Security', '', 'Arka Dharma'),
(1003, 'Admin Timbangan', '', 'Naila Azzahra'),
(1004, 'IT', '', 'Naila Azzahra'),
(1005, 'Kasir', '', 'Naila Azzahra'),
(1006, 'Adm. Gudang', '', 'Keenan Fadhlan'),
(1007, 'Store Kooper', '', 'Keenan Fadhlan'),
(1008, 'Pengawas Compound', '', 'Ayana Rasyidah'),
(1009, 'Mandor Compound', '', 'Ayana Rasyidah'),
(1010, 'Compound', '', 'Ayana Rasyidah'),
(1011, 'Admin HRD', '', 'Ayana Rasyidah'),
(1012, 'Admin Payroll', '', 'Ayana Rasyidah'),
(1013, 'Office Girl', '', 'Ayana Rasyidah'),
(1014, 'Mandor Proses B', '', 'Zhafran Malik'),
(1015, 'Operator Boiler B', '', 'Zhafran Malik'),
(1016, 'Attandant Operator B', '', 'Zhafran Malik'),
(1017, 'Attandant Operator B', '', 'Zhafran Malik'),
(1018, 'Operator Clarification', '', 'Zhafran Malik'),
(1019, 'Attandant Operator C', '', 'Zhafran Malik'),
(1020, 'Attandant Operator K', '', 'Zhafran Malik'),
(1021, 'Operator Kernel B', '', 'Zhafran Malik'),
(1022, 'Operator Steriliaer B', '', 'Zhafran Malik'),
(1023, 'Attandant Operator S', '', 'Zhafran Malik'),
(1024, 'Operator Loading Rar', '', 'Zhafran Malik'),
(1025, 'Operator Power Hous', '', 'Zhafran Malik'),
(1026, 'Operator Srew Press', '', 'Zhafran Malik'),
(1027, 'Operator Wheel Loader', '', 'Zhafran Malik'),
(1028, 'Operator WTP B', '', 'Zhafran Malik'),
(1029, 'USB Man', '', 'Zhafran Malik'),
(1030, 'Shift Fitter', '', 'Zhafran Malik'),
(1031, 'Mandor Proses A', '', 'Adinda Putri'),
(1032, 'Attandant Operator B', '', 'Adinda Putri'),
(1033, 'Attandant Operator B', '', 'Adinda Putri'),
(1034, 'Operator Clarification', '', 'Adinda Putri'),
(1035, 'Attandant Operator C', '', 'Adinda Putri'),
(1036, 'Attandant Operator K', '', 'Adinda Putri'),
(1037, 'Operator Kernel B', '', 'Adinda Putri'),
(1038, 'Operator Steriliaer B', '', 'Adinda Putri'),
(1039, 'Attandant Operator S', '', 'Adinda Putri'),
(1040, 'Operator Loading Rar', '', 'Adinda Putri'),
(1041, 'Operator Power Hous', '', 'Adinda Putri'),
(1042, 'Operator Srew Press', '', 'Adinda Putri'),
(1043, 'Operator Wheel Loader', '', 'Adinda Putri'),
(1044, 'Operator WTP B', '', 'Adinda Putri'),
(1045, 'USB Man', '', 'Adinda Putri'),
(1046, 'Shift Fitter', '', 'Adinda Putri'),
(1047, 'Admin Proses', '', 'Adinda Putri'),
(1048, 'Mandor Sortasi', '', 'Reyhan Mahendra'),
(1049, 'Operator WheelLoader', '', 'Reyhan Mahendra'),
(1050, 'Sortasi', '', 'Reyhan Mahendra'),
(1051, 'KA. Labor', '', 'Safira Amalia'),
(1052, 'Admin Labor', '', 'Safira Amalia'),
(1053, 'Analist Cairan', '', 'Safira Amalia'),
(1054, 'Analist Padatan', '', 'Safira Amalia'),
(1055, 'Despatch CPO', '', 'Safira Amalia'),
(1056, 'Despatch Kernel', '', 'Safira Amalia'),
(1057, 'Helper', '', 'Safira Amalia'),
(1058, 'Sample Boy', '', 'Safira Amalia'),
(1059, 'Sample Girl', '', 'Safira Amalia'),
(1060, 'Mandor Material Balance', '', 'Safira Amalia'),
(1061, 'Sample Material Balance', '', 'Safira Amalia'),
(1062, 'Operator Limbah', '', 'Safira Amalia'),
(1063, 'Attp Op. Limbah', '', 'Safira Amalia'),
(1064, 'Mandor Maintenance', '', 'Fabian Ramadhan'),
(1065, 'Mandor Maintenance B', '', 'Fabian Ramadhan'),
(1066, 'Admin Maintenance', '', 'Fabian Ramadhan'),
(1067, 'Driver DT Fuso', '', 'Fabian Ramadhan'),
(1068, 'Driver Dump Truck', '', 'Fabian Ramadhan'),
(1069, 'Driver Umum', '', 'Fabian Ramadhan'),
(1070, 'Electrical', '', 'Fabian Ramadhan'),
(1071, 'Oil Man', '', 'Fabian Ramadhan'),
(1072, 'Operator Mesin Bubut', '', 'Fabian Ramadhan'),
(1073, 'Zona 1', '', 'Fabian Ramadhan'),
(1074, 'Zona 2', '', 'Fabian Ramadhan'),
(1075, 'Zona 3', '', 'Fabian Ramadhan'),
(1076, 'Zona 4', '', 'Fabian Ramadhan'),
(1077, 'Zona 5', '', 'Fabian Ramadhan'),
(1078, 'Pimpinan', '', 'Kayla Nuraini');

-- --------------------------------------------------------

--
-- Table structure for table `jabatan`
--

CREATE TABLE `jabatan` (
  `id_jabatan` int NOT NULL,
  `kode_jab` varchar(50) NOT NULL,
  `nama_jabatan` varchar(128) NOT NULL,
  `gaji_pokok` varchar(128) NOT NULL,
  `tunjangan` varchar(128) NOT NULL,
  `lembur` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `jabatan`
--

INSERT INTO `jabatan` (`id_jabatan`, `kode_jab`, `nama_jabatan`, `gaji_pokok`, `tunjangan`, `lembur`) VALUES
(1, 'JA01', 'Direktur Utama', '5500000', '200000', '250000'),
(2, 'JA02', 'Mill Manager', '4500000', '100000', '150000'),
(3, 'JA03', 'Asisten Kepala', '4500000', '100000', '250000'),
(4, 'JA04', 'KTU', '5500000', '200000', '150000'),
(5, 'JA05', 'KA. HRD', '4500000', '100000', '250000'),
(13, 'JA07', 'KA. Gudang', '4500000', '100000', '150000'),
(14, 'JA08', 'KA. Satgas', '3500000', '100000', '150000'),
(15, 'JA09', 'ASST. Proses', '4500000', '100000', '150000'),
(16, 'JA10', 'SST. Maintenance', '4500000', '200000', '150000'),
(17, 'JA11', 'ASST. Lab', '3500000', '100000', '150000'),
(18, 'JA12', 'Komersial', '4500000', '100000', '250000'),
(19, 'JA13', 'ASST. Sortasi', '3500000', '100000', '150000'),
(20, 'JA14', 'Pegawai', '3000000', '100000', '50000');

-- --------------------------------------------------------

--
-- Table structure for table `lembur`
--

CREATE TABLE `lembur` (
  `id_lembur` int NOT NULL,
  `nip_pegawai` char(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `tgl_lembur` datetime NOT NULL,
  `lama_lembur` int NOT NULL,
  `keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `lembur`
--

INSERT INTO `lembur` (`id_lembur`, `nip_pegawai`, `tgl_lembur`, `lama_lembur`, `keterangan`) VALUES
(10, '0454897197', '2023-09-06 13:50:00', 2, 'Perbaikan kernel');

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `nip` char(20) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `jk_pegawai` enum('Laki-laki','Perempuan') NOT NULL,
  `status` varchar(50) NOT NULL,
  `agama` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `kode_jab` char(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `id_divisi` char(50) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `status_kawin` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`nip`, `nama`, `jk_pegawai`, `status`, `agama`, `alamat`, `kode_jab`, `id_divisi`, `tgl_masuk`, `status_kawin`) VALUES
('201210012', 'Sandi Maulidika', 'Laki-laki', 'Kontrak', 'Islam', 'Gelumbang', 'JA14', '1010', '2023-09-10', 'Sudah Kawin'),
('201210013', 'Robi Ropiah', 'Laki-laki', 'Pegawai Tetap', 'Islam', 'Gelumbang', 'JA05', '1078', '2023-08-29', 'Sudah Kawin'),
('201210014', 'Voni Puspita Sari', 'Perempuan', 'Kontrak', 'Islam', 'Gelumbang', 'JA14', '1013', '2023-09-10', 'Belum Kawin');

-- --------------------------------------------------------

--
-- Table structure for table `pinjaman`
--

CREATE TABLE `pinjaman` (
  `id_pinjaman` int NOT NULL,
  `nip_pegawai` char(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `besar_pinjaman` int NOT NULL,
  `sisa_pinjaman` int NOT NULL,
  `tenor` int NOT NULL,
  `cicilan` int NOT NULL,
  `tanggal` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `potongan`
--

CREATE TABLE `potongan` (
  `id_potongan` int NOT NULL,
  `hadir` char(11) NOT NULL,
  `sakit` char(11) NOT NULL,
  `mangkir` char(11) NOT NULL,
  `pph21` char(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `bpjskes` char(11) NOT NULL,
  `bpjsnaker` char(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `potongan`
--

INSERT INTO `potongan` (`id_potongan`, `hadir`, `sakit`, `mangkir`, `pph21`, `bpjskes`, `bpjsnaker`) VALUES
(1, '0', '0', '150000', '0', '35386', '102125');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id_setting` int NOT NULL,
  `nama_perusahaan` varchar(128) NOT NULL,
  `nama_aplikasi` varchar(128) NOT NULL,
  `tahun_berdiri` varchar(128) NOT NULL,
  `alamat` text NOT NULL,
  `logo` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id_setting`, `nama_perusahaan`, `nama_aplikasi`, `tahun_berdiri`, `alamat`, `logo`) VALUES
(1, 'PT. Sandemo', 'Penggajian Pegawai', '2024', 'Jl Ruslan, Kelurahan Kampal Kecamatan Parigi Kabupaten Parigi moutong Provinsi Sulawesi tengah.', 'pt_sandemo_1732565720.png');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int NOT NULL,
  `nama_lengkap` varchar(128) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `level` enum('admin','pimpinan','pegawai') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `foto_user` varchar(50) NOT NULL,
  `tanggal_klik_gaji` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_lengkap`, `username`, `password`, `level`, `foto_user`, `tanggal_klik_gaji`) VALUES
(1, 'Sandi Maulidika', '201210012', '$2y$10$ZSz8.P6GqdcoCas1p9Ve1u4br8JHd06gdX3.RSW5bPYqcOX0k5FIC', 'admin', 'default.svg', '2023-12-14'),
(10, 'Ruslan Ropiah', '201210013', '$2y$10$FshA2rh7nRnOuzJfElliB.9vpN8EqD5FfBwHsVzsQ6/Cj.VcNG6N2', 'pimpinan', 'default.svg', ''),
(13, 'Voni Puspita Sari', '201210014', '$2y$10$eCS8xD49xPMdRTGXdlAMh.X9TdxOVgKZmLPevwD5ve8vwkO8dqxUy', 'pegawai', 'default.svg', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id_absensi`);

--
-- Indexes for table `divisi`
--
ALTER TABLE `divisi`
  ADD PRIMARY KEY (`id_divisi`);

--
-- Indexes for table `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id_jabatan`);

--
-- Indexes for table `lembur`
--
ALTER TABLE `lembur`
  ADD PRIMARY KEY (`id_lembur`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`nip`),
  ADD KEY `id_jabatan` (`kode_jab`),
  ADD KEY `id_divisi` (`id_divisi`);

--
-- Indexes for table `pinjaman`
--
ALTER TABLE `pinjaman`
  ADD PRIMARY KEY (`id_pinjaman`);

--
-- Indexes for table `potongan`
--
ALTER TABLE `potongan`
  ADD PRIMARY KEY (`id_potongan`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id_setting`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id_absensi` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1372;

--
-- AUTO_INCREMENT for table `divisi`
--
ALTER TABLE `divisi`
  MODIFY `id_divisi` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1080;

--
-- AUTO_INCREMENT for table `jabatan`
--
ALTER TABLE `jabatan`
  MODIFY `id_jabatan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `lembur`
--
ALTER TABLE `lembur`
  MODIFY `id_lembur` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pinjaman`
--
ALTER TABLE `pinjaman`
  MODIFY `id_pinjaman` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `potongan`
--
ALTER TABLE `potongan`
  MODIFY `id_potongan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id_setting` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
