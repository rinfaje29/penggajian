<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Setting extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->username])->row_array();
        $data['title'] = 'Setting Aplikasi ' . get_setting('nama_aplikasi');

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('setting');
        $this->load->view('templates/footer');
    }

    public function update()
    {
        // Validasi input kosong
        $this->form_validation->set_rules('nama_perusahaan', 'Nama Perusahaan', 'required|trim');
        $this->form_validation->set_rules('nama_aplikasi', 'Nama Aplikasi', 'required|trim');
        $this->form_validation->set_rules('tahun_berdiri', 'Tahun Berdiri', 'required|trim|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');

        if ($this->form_validation->run() == false) {
            set_pesan(validation_errors(), false);
            redirect('setting');
        }

        $data = [
            'nama_perusahaan' => htmlspecialchars($this->input->post('nama_perusahaan', true)),
            'nama_aplikasi' => htmlspecialchars($this->input->post('nama_aplikasi', true)),
            'tahun_berdiri' => htmlspecialchars($this->input->post('tahun_berdiri', true)),
            'alamat' => htmlspecialchars($this->input->post('alamat', true))
        ];

        // Proses upload logo jika ada
        $upload_image = $_FILES['logo']['name'];
        if ($upload_image) {
            $upload_path = FCPATH . 'assets/img/logo';
            if (!is_dir($upload_path)) {
                mkdir($upload_path, 0755, true); // Buat folder jika belum ada
            }

            $config['upload_path']   = $upload_path;
            $config['allowed_types'] = 'jpg|png|jpeg|webp';
            $config['max_size']      = 2048; // 2MB
            $config['file_name']     = strtolower(url_title($this->input->post('nama_perusahaan', true), '_', true)) . '_' . time();

            $this->upload->initialize($config);

            if ($this->upload->do_upload('logo')) {
                // Hapus logo lama jika ada
                $old_logo = get_setting('logo');
                if ($old_logo && file_exists(FCPATH . 'assets/img/logo/' . $old_logo)) {
                    unlink(FCPATH . 'assets/img/logo/' . $old_logo);
                }

                // Simpan nama file logo baru ke data
                $data['logo'] = $this->upload->data('file_name');
            } else {
                set_pesan($this->upload->display_errors(), false);
                redirect('setting');
            }
        }

        $this->db->update('setting', $data);

        set_pesan('Data berhasil diupdate');
        redirect('setting');
    }
}
