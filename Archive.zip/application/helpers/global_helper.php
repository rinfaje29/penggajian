<?php
if (!function_exists('get_setting')) {
    function get_setting($column_name)
    {
        $CI = &get_instance();
        $CI->load->library('globale');

        $managements = $CI->globale->get_settings();

        return isset($managements[$column_name]) ? $managements[$column_name] : '';
    }
}
