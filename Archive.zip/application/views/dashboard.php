<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Selamat datang di <?= get_setting('nama_aplikasi') . ' ' . get_setting('nama_perusahaan') ?></h1>
    </div>

    <!-- Content Row -->
    <?php if ($user['level'] == 'admin' || $user['level'] == 'pimpinan') : ?>
        <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Pegawai</div>
                                <div class="col-auto">
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_pegawai ?></div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fa-solid fa-users fa-2x text-gray-300 mr-3"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <?php if (is_admin()) : ?>
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                        User</div>
                                    <div class="col-auto">
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_user ?></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-user fa-2x text-gray-300 mr-3"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else : ?>
            <?php endif ?>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Jabatan
                                </div>
                                <div class="col-auto">
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_jabatan ?></div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fa-solid fa-user-tie fa-2x text-gray-300 mr-3"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                    Divisi</div>
                                <div class="col-auto">
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_divisi ?></div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fa-solid fa-user-gear fa-2x text-gray-300 mr-3"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else : ?>
        <div class="row">
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Divisi</div>
                                <div class="col-auto">
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $divisi['nama_divisi'] ?></div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fa-regular fa-user fa-2x text-gray-300 mr-3"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif ?>

    <!-- Content Row -->