<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= $title; ?></h1>
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-6">
            <?= $this->session->flashdata('message'); ?>
            <div class="card shadow mb-4">
                <div class="card-body">
                    <?= form_open_multipart('setting/update'); ?>
                    <div class="form-group">
                        <label>Nama Perusahaan</label>
                        <input type="text" class="form-control" name="nama_perusahaan" id="nama_perusahaan" placeholder="Enter nama perusaan" value="<?= set_value('nama_perusahaan', get_setting('nama_perusahaan')) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Nama Aplikasi</label>
                        <input type="text" class="form-control" name="nama_aplikasi" id="nama_aplikasi" placeholder="Enter nama aplikasi" value="<?= set_value('nama_aplikasi', get_setting('nama_aplikasi')) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Tahun Berdiri</label>
                        <input type="text" class="form-control" name="tahun_berdiri" id="tahun_berdiri" placeholder="Enter tahun berdiri" value="<?= set_value('tahun_berdiri', get_setting('tahun_berdiri')) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Alamat</label>
                        <input type="text" class="form-control" name="alamat" id="alamat" placeholder="Enter alamat" value="<?= set_value('alamat', get_setting('alamat')) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Logo</label>
                        <input type="file" class="form-control" name="logo" id="logo" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>