# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [1.1.1](///compare/v1.1.0...v1.1.1) (2023-08-15)

## 1.1.0 (2023-08-15)


### Features

* add standard release suport! cc15cdb
